package com.dukan.sahayak;

import android.accessibilityservice.AccessibilityService;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import java.util.List;

/* Presses WhatsApp's Send button, but ONLY while the app has asked to send a bill (pending = true). */
public class WaService extends AccessibilityService {
  static volatile boolean pending = false;
  static volatile long pendingAt = 0;

  @Override public void onAccessibilityEvent(AccessibilityEvent e) {
    if (!pending) return;
    if (System.currentTimeMillis() - pendingAt > 30000) { pending = false; return; }
    AccessibilityNodeInfo root = getRootInActiveWindow();
    if (root == null) return;
    String pk = String.valueOf(root.getPackageName());
    if (!pk.startsWith("com.whatsapp")) return;
    AccessibilityNodeInfo n = byId(root, pk + ":id/send");
    if (n == null) n = byDesc(root);
    if (n == null) return;
    AccessibilityNodeInfo c = n;
    while (c != null && !c.isClickable()) c = c.getParent();
    if (c == null) return;
    pending = false;
    c.performAction(AccessibilityNodeInfo.ACTION_CLICK);
    MainActivity m = MainActivity.inst;
    if (m != null) m.waSent();
  }

  AccessibilityNodeInfo byId(AccessibilityNodeInfo r, String id) {
    List<AccessibilityNodeInfo> l = r.findAccessibilityNodeInfosByViewId(id);
    return (l != null && !l.isEmpty()) ? l.get(0) : null;
  }

  AccessibilityNodeInfo byDesc(AccessibilityNodeInfo r) {
    for (String d : new String[]{"Send", "भेजें"}) {
      List<AccessibilityNodeInfo> l = r.findAccessibilityNodeInfosByText(d);
      if (l == null) continue;
      for (AccessibilityNodeInfo n : l) {
        CharSequence cd = n.getContentDescription();
        if (cd != null && cd.toString().equalsIgnoreCase(d)) return n;
      }
    }
    return null;
  }

  @Override public void onInterrupt() {}
}
