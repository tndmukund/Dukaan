package com.dukan.sahayak;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.speech.RecognizerIntent;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Locale;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import org.json.JSONObject;
import org.vosk.Model;
import org.vosk.Recognizer;
import org.vosk.android.RecognitionListener;
import org.vosk.android.SpeechService;

/*
 * Voice design: offline Hindi recognition (Vosk). The mic is opened once per turn and closed while the
 * phone is speaking, so nothing keeps "resetting". The Hindi model (~42 MB) downloads once, then works offline.
 * Fallback: the 🗣️ button opens Google's voice window.
 */
public class MainActivity extends Activity {
  static final int REQ_SPEECH = 77;
  static final String MODEL_URL = "https://alphacephei.com/vosk/models/vosk-model-small-hi-0.22.zip";
  WebView w;
  TextToSpeech tts;
  Model model;
  SpeechService svc;
  Recognizer rec;
  Handler hd = new Handler(Looper.getMainLooper());
  boolean keep = false, wantListen = false, speaking = false, ttsReady = false;
  boolean asleep = false;
  boolean modelReady = false, modelFailed = false, skipResume = false, resumeAfter = false;
  String pending = null;
  final Runnable applyTask = () -> applyMic();
  final Runnable idleTask = () -> {
    if (asleep) return;
    if (speaking) { touch(); return; }
    asleep = true;
    js("onSleep()");
    st("😴 जगाने के लिए \"दुकान सहायक\" बोलिए");
  };
  void touch() { hd.removeCallbacks(idleTask); if (keep && !asleep) hd.postDelayed(idleTask, 30000); }
  String wakeRest(String t) {
    if (!t.matches(".*(दुकान|सहायक|सहायता).*")) return null;
    return t.replaceAll("दुकान\\s*सहायक|दुकान\\s*सहायता|दुकान|सहायक|सहायता", " ").trim();
  }

  @Override protected void onCreate(Bundle b) {
    super.onCreate(b);
    getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
    requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, 1);
    w = new WebView(this);
    setContentView(w);
    WebSettings s = w.getSettings();
    s.setJavaScriptEnabled(true);
    s.setDomStorageEnabled(true);
    w.setWebViewClient(new WebViewClient() {
      @Override public void onPageFinished(WebView v, String u) {
        if (hasMic()) hd.postDelayed(() -> js("autoStart()"), 1500);
      }
      @Override public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
        if (r.getUrl().toString().startsWith("file:")) return false;
        try { startActivity(new Intent(Intent.ACTION_VIEW, r.getUrl())); } catch (Exception e) {}
        return true;
      }
    });

    tts = new TextToSpeech(this, st -> {
      if (st != TextToSpeech.SUCCESS) { err("फ़ोन में Text-to-speech इंजन नहीं मिला। Settings > Text-to-speech में Google इंजन चुनें।"); return; }
      int r = tts.setLanguage(new Locale("hi", "IN"));
      if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
        err("हिंदी आवाज़ फ़ोन में नहीं है। खुलने वाली स्क्रीन में Hindi डाउनलोड करें, फिर ऐप दोबारा खोलें।");
        try { startActivity(new Intent(TextToSpeech.Engine.ACTION_INSTALL_TTS_DATA)); } catch (Exception e) {}
      }
      tts.setSpeechRate(0.95f);
      ttsReady = true;
      if (pending != null) { String p = pending; pending = null; doSpeak(p); }
    });
    tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
      public void onStart(String id) { speaking = true; }
      public void onError(String id) { hd.post(() -> afterSpeak()); }
      public void onDone(String id) { hd.post(() -> afterSpeak()); }
    });

    w.addJavascriptInterface(new Bridge(), "Android");
    w.loadUrl("file:///android_asset/index.html");
    initModel();
  }

  boolean hasMic() { return checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED; }
  void st(String m) { js("onStatus(" + JSONObject.quote(m) + ")"); }
  void js(String code) { runOnUiThread(() -> w.evaluateJavascript(code, null)); }
  void err(String m) { hd.postDelayed(() -> js("onVoiceErr(" + JSONObject.quote(m) + ")"), 2500); }
  void schedule(int ms) { hd.removeCallbacks(applyTask); hd.postDelayed(applyTask, ms); }

  // ---------- Hindi model: download once, then offline ----------
  void initModel() {
    new Thread(() -> {
      try {
        File dir = new File(getFilesDir(), "vosk-hi");
        if (!new File(dir, "am/final.mdl").exists()) {
          st("⬇️ हिंदी आवाज़ मॉडल उतर रहा है (सिर्फ़ पहली बार, ~42 MB, इंटरनेट चाहिए)…");
          download(dir);
        }
        st("मॉडल लोड हो रहा है…");
        model = new Model(dir.getAbsolutePath());
        modelReady = true;
        st("✅ तैयार");
        hd.post(() -> applyMic());
      } catch (Throwable e) {
        modelFailed = true;
        err("हिंदी आवाज़ मॉडल नहीं उतर पाया (" + e.getClass().getSimpleName() + "). इंटरनेट चालू करके ऐप दोबारा खोलें। तब तक 🗣️ बटन से Google माइक चलेगा।");
      }
    }).start();
  }

  void download(File dir) throws Exception {
    File tmp = new File(getFilesDir(), "vosk-tmp");
    deleteAll(tmp);
    tmp.mkdirs();
    String base = tmp.getCanonicalPath() + File.separator;
    HttpURLConnection c = (HttpURLConnection) new URL(MODEL_URL).openConnection();
    c.setConnectTimeout(20000); c.setReadTimeout(30000);
    long total = c.getContentLengthLong(), got = 0; int lastPct = -1;
    try (ZipInputStream z = new ZipInputStream(new CountIn(c.getInputStream()))) {
      ZipEntry e; byte[] buf = new byte[65536];
      while ((e = z.getNextEntry()) != null) {
        String n = e.getName(); int i = n.indexOf('/');
        if (i < 0) continue;
        n = n.substring(i + 1);
        if (n.isEmpty()) continue;
        File f = new File(tmp, n);
        if (!f.getCanonicalPath().startsWith(base)) continue;
        if (e.isDirectory()) { f.mkdirs(); continue; }
        f.getParentFile().mkdirs();
        try (OutputStream o = new FileOutputStream(f)) { int r; while ((r = z.read(buf)) > 0) o.write(buf, 0, r); }
        if (total > 0) { int p = (int) (cnt * 100 / total); if (p != lastPct && p % 5 == 0) { lastPct = p; st("⬇️ हिंदी मॉडल " + p + "%"); } }
      }
    }
    deleteAll(dir);
    if (!tmp.renameTo(dir)) throw new Exception("rename failed");
  }
  long cnt = 0;
  class CountIn extends java.io.FilterInputStream {
    CountIn(InputStream in) { super(in); }
    @Override public int read(byte[] b, int o, int l) throws java.io.IOException { int r = super.read(b, o, l); if (r > 0) cnt += r; return r; }
    @Override public int read() throws java.io.IOException { int r = super.read(); if (r >= 0) cnt++; return r; }
  }
  void deleteAll(File f) {
    if (!f.exists()) return;
    File[] k = f.listFiles();
    if (k != null) for (File x : k) deleteAll(x);
    f.delete();
  }

  // ---------- mic on/off (single owner) ----------
  void applyMic() {
    boolean want = (keep || wantListen) && !speaking && modelReady && hasMic();
    if (want && svc == null) startMic();
    else if (!want && svc != null) stopMic();
  }

  void startMic() {
    try {
      rec = new Recognizer(model, 16000.0f);
      svc = new SpeechService(rec, 16000.0f);
      svc.startListening(new RecognitionListener() {
        public void onPartialResult(String h) {
          if (asleep) return;
          try { String p = new JSONObject(h).optString("partial"); if (!p.isEmpty()) js("onPartial(" + JSONObject.quote(p) + ")"); } catch (Exception e) {}
        }
        public void onResult(String h) {
          String t = "";
          try { t = new JSONObject(h).optString("text").trim(); } catch (Exception e) {}
          if (t.isEmpty()) return;
          if (asleep) {
            String rest = wakeRest(t);
            if (rest == null) return; // ignore everything except the wake word
            asleep = false; touch(); stopMic();
            js("onWake(" + JSONObject.quote(rest) + ")");
            schedule(5000);
            return;
          }
          touch();
          stopMic();
          js("onVoice(" + JSONObject.quote(t) + ")");
          schedule(5000); // safety net; speak() cancels it
        }
        public void onFinalResult(String h) {}
        public void onError(Exception e) { stopMic(); st("माइक फिर शुरू हो रहा है…"); schedule(1500); }
        public void onTimeout() {}
      });
      st(asleep ? "😴 जगाने के लिए \"दुकान सहायक\" बोलिए" : "🎤 बोलिए…");
    } catch (Throwable e) {
      stopMic();
      st("माइक शुरू नहीं हुआ — 🎤 दबाइए");
    }
  }

  void stopMic() {
    try { if (svc != null) { svc.cancel(); svc.shutdown(); } } catch (Throwable e) {}
    try { if (rec != null) rec.close(); } catch (Throwable e) {}
    svc = null; rec = null;
  }

  // ---------- speaking ----------
  void doSpeak(String t) {
    speaking = true;
    int r = tts.speak(t, TextToSpeech.QUEUE_FLUSH, null, "u");
    if (r != TextToSpeech.SUCCESS) { speaking = false; afterSpeak(); }
  }
  void afterSpeak() { speaking = false; touch(); schedule(600); }

  // ---------- Google voice window (fallback) ----------
  void dialogListen() {
    stopMic();
    try { if (speaking) tts.stop(); } catch (Exception e) {}
    speaking = false;
    Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
    i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
    i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN");
    i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "hi-IN");
    try { skipResume = true; startActivityForResult(i, REQ_SPEECH); }
    catch (Exception e) { skipResume = false; js("onVoiceErr('Google आवाज़ ऐप नहीं मिला। नीचे टाइप करें।')"); }
  }

  @Override protected void onActivityResult(int rq, int rs, Intent d) {
    super.onActivityResult(rq, rs, d);
    if (rq != REQ_SPEECH) return;
    ArrayList<String> l = (rs == RESULT_OK && d != null) ? d.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS) : null;
    if (l != null && !l.isEmpty() && !l.get(0).trim().isEmpty()) { asleep = false; touch(); js("onVoice(" + JSONObject.quote(l.get(0)) + ")"); }
  }

  // ---------- lifecycle ----------
  @Override public void onRequestPermissionsResult(int c, String[] p, int[] r) {
    if (r.length > 0 && r[0] == PackageManager.PERMISSION_GRANTED) { hd.postDelayed(() -> js("autoStart()"), 800); schedule(1500); }
  }
  @Override protected void onPause() {
    super.onPause();
    if (skipResume) return;
    resumeAfter = keep;
    hd.removeCallbacks(applyTask);
    stopMic();
    try { if (speaking) tts.stop(); } catch (Exception e) {}
    speaking = false;
  }
  @Override protected void onResume() {
    super.onResume();
    if (skipResume) { skipResume = false; return; }
    if (resumeAfter && keep) schedule(1000);
  }
  @Override protected void onDestroy() {
    hd.removeCallbacks(applyTask);
    stopMic();
    try { if (model != null) model.close(); } catch (Throwable e) {}
    try { if (tts != null) { tts.stop(); tts.shutdown(); } } catch (Exception e) {}
    super.onDestroy();
  }

  public class Bridge {
    @JavascriptInterface public void speak(String t, boolean listen) {
      runOnUiThread(() -> {
        wantListen = listen;
        hd.removeCallbacks(applyTask);
        stopMic();
        if (!ttsReady) { pending = t; return; }
        doSpeak(t);
      });
    }
    @JavascriptInterface public void listen() {
      runOnUiThread(() -> {
        if (!modelReady && modelFailed) { dialogListen(); return; }
        wantListen = true; asleep = false; touch();
        try { if (speaking) tts.stop(); } catch (Exception e) {}
        speaking = false;
        stopMic();
        schedule(150);
      });
    }
    @JavascriptInterface public void sleep() { runOnUiThread(() -> { asleep = true; hd.removeCallbacks(idleTask); }); }
    @JavascriptInterface public void dialogListen() { runOnUiThread(() -> MainActivity.this.dialogListen()); }
    @JavascriptInterface public void keepOpen(boolean k) {
      runOnUiThread(() -> { keep = k; if (!k) wantListen = false; else touch(); schedule(100); });
    }
  }
}
