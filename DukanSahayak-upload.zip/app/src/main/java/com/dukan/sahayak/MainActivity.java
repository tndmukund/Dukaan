package com.dukan.sahayak;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.speech.RecognizerIntent;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Locale;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import com.google.mlkit.vision.codescanner.GmsBarcodeScannerOptions;
import com.google.mlkit.vision.codescanner.GmsBarcodeScanning;
import com.google.mlkit.vision.barcode.BarcodeScannerOptions;
import com.google.mlkit.vision.barcode.BarcodeScanning;
import com.google.mlkit.vision.barcode.common.Barcode;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.documentscanner.GmsDocumentScannerOptions;
import com.google.mlkit.vision.documentscanner.GmsDocumentScanning;
import com.google.mlkit.vision.documentscanner.GmsDocumentScanningResult;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;
import org.json.JSONArray;
import org.json.JSONObject;
import org.vosk.Model;
import org.vosk.Recognizer;
import org.vosk.android.RecognitionListener;
import org.vosk.android.SpeechService;

/*
 * Voice design: offline Hindi recognition (Vosk). The mic is opened once per turn and closed while the
 * phone is speaking, so nothing keeps "resetting". The Hindi model (~42 MB) downloads once, then works offline.
 * Fallback: the 🗣️ button opens Google's voice window.
 */
public class MainActivity extends Activity {
  static final int REQ_SPEECH = 77, REQ_DOC = 78, REQ_CAM = 79;
  static final String MODEL_URL = "https://alphacephei.com/vosk/models/vosk-model-small-hi-0.22.zip";
  WebView w;
  TextToSpeech tts;
  Model model, modelEn;
  boolean enReady = false, enMode = false;
  SpeechService svc;
  Recognizer rec;
  Handler hd = new Handler(Looper.getMainLooper());
  boolean keep = false, wantListen = false, speaking = false, ttsReady = false;
  boolean asleep = false;
  boolean modelReady = false, modelFailed = false, skipResume = false, resumeAfter = false;
  String pending = null;
  volatile String grammar = null;   // word list from the shop's own items/customers (set by the page)
  volatile boolean panelOpen = false;
  static MainActivity inst;
  final Runnable waTimeout = () -> {
    if (WaService.pending) { WaService.pending = false; toFront(); js("onWaFail()"); }
  };
  void toFront() {
    try {
      Intent i = new Intent(this, MainActivity.class);
      i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_REORDER_TO_FRONT | Intent.FLAG_ACTIVITY_SINGLE_TOP);
      startActivity(i);
    } catch (Exception e) {}
  }
  void waSent() {
    hd.postDelayed(() -> { hd.removeCallbacks(waTimeout); toFront(); hd.postDelayed(() -> js("onWaSent()"), 700); }, 1200);
  }
  final Runnable applyTask = () -> applyMic();
  final Runnable idleTask = () -> {
    if (asleep) return;
    if (speaking) { touch(); return; }
    asleep = true; enMode = false;
    js("onLang('hi')");
    js("onSleep()");
    st("😴 जगाने के लिए \"दुकान सहायक\" बोलिए");
  };
  void touch() { hd.removeCallbacks(idleTask); if (keep && !asleep) hd.postDelayed(idleTask, 30000); }
  String wakeRest(String t) {
    if (!t.matches(".*(दुकान|सहायक|सहायता).*")) return null;
    return t.replaceAll("दुकान\\s*सहायक|दुकान\\s*सहायता|दुकान|सहायक|सहायता", " ").trim();
  }

  @Override protected void onCreate(Bundle b) {
    super.onCreate(b);
    inst = this;
    getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
    requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, 1);
    w = new WebView(this);
    setContentView(w);
    WebSettings s = w.getSettings();
    s.setJavaScriptEnabled(true);
    s.setDomStorageEnabled(true);
    w.setWebViewClient(new WebViewClient() {
      @Override public void onPageFinished(WebView v, String u) {
        if (hasMic()) hd.postDelayed(() -> js("autoStart()"), 1500);
      }
      @Override public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
        if (r.getUrl().toString().startsWith("file:")) return false;
        try { startActivity(new Intent(Intent.ACTION_VIEW, r.getUrl())); } catch (Exception e) {}
        return true;
      }
    });

    tts = new TextToSpeech(this, st -> {
      if (st != TextToSpeech.SUCCESS) { err("फ़ोन में Text-to-speech इंजन नहीं मिला। Settings > Text-to-speech में Google इंजन चुनें।"); return; }
      int r = tts.setLanguage(new Locale("hi", "IN"));
      if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
        err("हिंदी आवाज़ फ़ोन में नहीं है। खुलने वाली स्क्रीन में Hindi डाउनलोड करें, फिर ऐप दोबारा खोलें।");
        try { startActivity(new Intent(TextToSpeech.Engine.ACTION_INSTALL_TTS_DATA)); } catch (Exception e) {}
      }
      tts.setSpeechRate(1.1f);
      ttsReady = true;
      if (pending != null) { String p = pending; pending = null; doSpeak(p); }
    });
    tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
      public void onStart(String id) { speaking = true; }
      public void onError(String id) { hd.post(() -> afterSpeak()); }
      public void onDone(String id) { hd.post(() -> afterSpeak()); }
    });

    w.addJavascriptInterface(new Bridge(), "Android");
    w.loadUrl("file:///android_asset/index.html");
    initModel();
    sweepScans();
  }

  boolean hasMic() { return checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED; }
  void st(String m) { js("onStatus(" + JSONObject.quote(m) + ")"); }
  void js(String code) { runOnUiThread(() -> w.evaluateJavascript(code, null)); }
  void err(String m) { hd.postDelayed(() -> js("onVoiceErr(" + JSONObject.quote(m) + ")"), 2500); }
  void schedule(int ms) { hd.removeCallbacks(applyTask); hd.postDelayed(applyTask, ms); }

  // ---------- Hindi model: download once, then offline ----------
  void initModel() {
    new Thread(() -> {
      try {
        File dir = new File(getFilesDir(), "vosk-hi");
        if (!new File(dir, "am/final.mdl").exists()) {
          String[] la = null;
          try { la = getAssets().list("model-hi"); } catch (Exception e) {}
          if (la != null && la.length > 0) {
            st("आवाज़ मॉडल तैयार हो रहा है (सिर्फ़ पहली बार, कुछ सेकंड)…");
            File tmp = new File(getFilesDir(), "vosk-tmp");
            deleteAll(tmp);
            copyAsset("model-hi", tmp);
            deleteAll(dir);
            if (!tmp.renameTo(dir)) throw new Exception("rename failed");
          } else {
            st("⬇️ हिंदी आवाज़ मॉडल उतर रहा है (सिर्फ़ पहली बार, ~42 MB, इंटरनेट चाहिए)…");
            download(dir);
          }
        }
        st("मॉडल लोड हो रहा है…");
        model = new Model(dir.getAbsolutePath());
        modelReady = true;
        st("✅ तैयार");
        hd.post(() -> applyMic());
        initModelEn();
      } catch (Throwable e) {
        modelFailed = true;
        err("हिंदी आवाज़ मॉडल नहीं उतर पाया (" + e.getClass().getSimpleName() + "). इंटरनेट चालू करके ऐप दोबारा खोलें। तब तक 🗣️ बटन से Google माइक चलेगा।");
      }
    }).start();
  }

  // English (Indian) model is shipped inside the APK too (assets/model-en); if it is missing the 🇬🇧 button uses Google's window.
  void initModelEn() {
    new Thread(() -> {
      try {
        String[] la = null;
        try { la = getAssets().list("model-en"); } catch (Exception e) {}
        if (la == null || la.length == 0) return;
        File dir = new File(getFilesDir(), "vosk-en");
        if (!new File(dir, "am").isDirectory()) {
          File tmp = new File(getFilesDir(), "vosk-en-tmp");
          deleteAll(tmp);
          copyAsset("model-en", tmp);
          deleteAll(dir);
          if (!tmp.renameTo(dir)) throw new Exception("rename failed");
        }
        modelEn = new Model(dir.getAbsolutePath());
        enReady = true;
        js("onEnReady()");
      } catch (Throwable e) {}
    }).start();
  }

  void download(File dir) throws Exception {
    File tmp = new File(getFilesDir(), "vosk-tmp");
    deleteAll(tmp);
    tmp.mkdirs();
    String base = tmp.getCanonicalPath() + File.separator;
    HttpURLConnection c = (HttpURLConnection) new URL(MODEL_URL).openConnection();
    c.setConnectTimeout(20000); c.setReadTimeout(30000);
    long total = c.getContentLengthLong(), got = 0; int lastPct = -1;
    try (ZipInputStream z = new ZipInputStream(new CountIn(c.getInputStream()))) {
      ZipEntry e; byte[] buf = new byte[65536];
      while ((e = z.getNextEntry()) != null) {
        String n = e.getName(); int i = n.indexOf('/');
        if (i < 0) continue;
        n = n.substring(i + 1);
        if (n.isEmpty()) continue;
        File f = new File(tmp, n);
        if (!f.getCanonicalPath().startsWith(base)) continue;
        if (e.isDirectory()) { f.mkdirs(); continue; }
        f.getParentFile().mkdirs();
        try (OutputStream o = new FileOutputStream(f)) { int r; while ((r = z.read(buf)) > 0) o.write(buf, 0, r); }
        if (total > 0) { int p = (int) (cnt * 100 / total); if (p != lastPct && p % 5 == 0) { lastPct = p; st("⬇️ हिंदी मॉडल " + p + "%"); } }
      }
    }
    deleteAll(dir);
    if (!tmp.renameTo(dir)) throw new Exception("rename failed");
  }
  long cnt = 0;
  class CountIn extends java.io.FilterInputStream {
    CountIn(InputStream in) { super(in); }
    @Override public int read(byte[] b, int o, int l) throws java.io.IOException { int r = super.read(b, o, l); if (r > 0) cnt += r; return r; }
    @Override public int read() throws java.io.IOException { int r = super.read(); if (r >= 0) cnt++; return r; }
  }
  void copyAsset(String path, File out) throws Exception {
    String[] k = getAssets().list(path);
    if (k != null && k.length > 0) {
      out.mkdirs();
      for (String x : k) copyAsset(path + "/" + x, new File(out, x));
    } else {
      out.getParentFile().mkdirs();
      try (InputStream in = getAssets().open(path); OutputStream o = new FileOutputStream(out)) {
        byte[] b = new byte[65536]; int r;
        while ((r = in.read(b)) > 0) o.write(b, 0, r);
      }
    }
  }
  void deleteAll(File f) {
    if (!f.exists()) return;
    File[] k = f.listFiles();
    if (k != null) for (File x : k) deleteAll(x);
    f.delete();
  }

  // ---------- mic on/off (single owner) ----------
  void applyMic() {
    boolean want = (keep || wantListen) && !speaking && modelReady && hasMic();
    if (want && svc == null) startMic();
    else if (!want && svc != null) stopMic();
  }

  void startMic() {
    try {
      rec = makeRec();
      svc = new SpeechService(rec, 16000.0f);
      svc.startListening(new RecognitionListener() {
        public void onPartialResult(String h) {
          if (asleep) return;
          try { String p = clean(new JSONObject(h).optString("partial")); if (!p.isEmpty()) js("onPartial(" + JSONObject.quote(p) + ")"); } catch (Exception e) {}
        }
        public void onResult(String h) {
          String t = "";
          try { t = clean(new JSONObject(h).optString("text")); } catch (Exception e) {}
          if (t.isEmpty()) return; // silence / background noise ("[unk]" only): keep listening, don't wake the page
          if (asleep) {
            String rest = wakeRest(t);
            if (rest == null) return; // ignore everything except the wake word
            asleep = false; touch(); stopMic();
            js("onWake(" + JSONObject.quote(rest) + ")");
            schedule(5000);
            return;
          }
          touch();
          stopMic();
          js("onVoice(" + JSONObject.quote(t) + ")");
          schedule(5000); // safety net; speak() cancels it
        }
        public void onFinalResult(String h) {}
        public void onError(Exception e) { stopMic(); st("माइक फिर शुरू हो रहा है…"); schedule(1500); }
        public void onTimeout() {}
      });
      st(asleep ? "😴 जगाने के लिए \"दुकान सहायक\" बोलिए" : "🎤 बोलिए…");
    } catch (Throwable e) {
      stopMic();
      st("माइक शुरू नहीं हुआ — 🎤 दबाइए");
    }
  }

  // Recognizer that only listens for the words in `grammar` (items, customers, commands, numbers);
  // everything else becomes [unk] and is dropped. Falls back to free speech if no grammar / not supported.
  Recognizer makeRec() throws Exception {
    Recognizer r = null;
    Model m = (enMode && enReady && modelEn != null) ? modelEn : model;
    if (grammar != null) { try { r = new Recognizer(m, 16000.0f, grammar); } catch (Throwable e) { r = null; } }
    if (r == null) r = new Recognizer(m, 16000.0f);
    // shorter end-of-speech wait; only applies if this Vosk version has it, silently skipped otherwise
    try {
      Class<?> ec = Class.forName("org.vosk.EndpointerMode");
      for (Object o : ec.getEnumConstants()) {
        if (o.toString().equals("SHORT")) { r.getClass().getMethod("setEndpointerMode", ec).invoke(r, o); break; }
      }
    } catch (Throwable e) {}
    return r;
  }
  String clean(String t) { return t == null ? "" : t.replace("[unk]", " ").replaceAll("\\s+", " ").trim(); }

  void stopMic() {
    try { if (svc != null) { svc.cancel(); svc.shutdown(); } } catch (Throwable e) {}
    try { if (rec != null) rec.close(); } catch (Throwable e) {}
    svc = null; rec = null;
  }

  // ---------- speaking ----------
  void doSpeak(String t) {
    speaking = true;
    int r = tts.speak(t, TextToSpeech.QUEUE_FLUSH, null, "u");
    if (r != TextToSpeech.SUCCESS) { speaking = false; afterSpeak(); }
  }
  void afterSpeak() { speaking = false; touch(); schedule(250); }

  // ---------- Google voice window (fallback) ----------
  void dialogListen() { dialogListen("hi-IN"); }
  void dialogListen(String lang) {
    stopMic();
    try { if (speaking) tts.stop(); } catch (Exception e) {}
    speaking = false;
    Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
    i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
    i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, lang);
    i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, lang);
    try { skipResume = true; startActivityForResult(i, REQ_SPEECH); }
    catch (Exception e) { skipResume = false; js("onVoiceErr('Google आवाज़ ऐप नहीं मिला। नीचे टाइप करें।')"); }
  }

  @Override protected void onActivityResult(int rq, int rs, Intent d) {
    super.onActivityResult(rq, rs, d);
    if (rq == REQ_DOC) { if (rs == RESULT_OK && d != null) readPack(d); return; }
    if (rq == REQ_CAM) { camResult(rs); return; }
    if (rq != REQ_SPEECH) return;
    ArrayList<String> l = (rs == RESULT_OK && d != null) ? d.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS) : null;
    if (l != null && !l.isEmpty() && !l.get(0).trim().isEmpty()) { asleep = false; touch(); js("onVoice(" + JSONObject.quote(l.get(0)) + ")"); }
    else schedule(400);
  }

  // ---------- barcode scanner (Google code scanner: no camera code / permission needed) ----------
  // One scan per button press (the camera is never re-opened by itself, so one packet can't be counted twice).
  void scan(String mode) {
    try {
      stopMic();
      GmsBarcodeScanning.getClient(this, new GmsBarcodeScannerOptions.Builder().build()).startScan()
        .addOnSuccessListener(b -> {
          String c = b.getRawValue();
          w.evaluateJavascript("onBarcode(" + JSONObject.quote(c == null ? "" : c) + "," + JSONObject.quote(mode) + ")", v -> {
            if ("\"pack\"".equals(v)) hd.postDelayed(() -> scanPack(), 500);
          });
        })
        .addOnFailureListener(e -> js("onVoiceErr(" + JSONObject.quote("स्कैनर नहीं खुला (Google Play services चाहिए, पहली बार इंटरनेट): " + e.getMessage()) + ")"));
    } catch (Throwable e) {
      js("onVoiceErr(" + JSONObject.quote("स्कैनर नहीं खुला: " + e.getMessage()) + ")");
    }
  }

  // ---------- packet text reader: photo of the pack -> price / weight / batch / dates ----------
  String pendingField = "";
  int capLeft = 0;
  File capFile = null;
  final java.util.List<Uri> capGot = new ArrayList<>();
  void scanPack() { scanPack(2, ""); }
  // uses the phone's own camera app (full resolution, same quality as the normal camera) instead of the low-res document scanner
  void scanPack(int pages, String field) {
    pendingField = field == null ? "" : field;
    capLeft = pages;
    capGot.clear();
    stopMic();
    launchCamera();
  }
  void launchCamera() {
    try {
      capFile = new File(getCacheDir(), "docscan_" + System.currentTimeMillis() + ".jpg");
      Uri u = androidx.core.content.FileProvider.getUriForFile(this, getPackageName() + ".fp", capFile);
      Intent i = new Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE);
      i.putExtra(android.provider.MediaStore.EXTRA_OUTPUT, u);
      i.setClipData(android.content.ClipData.newRawUri("", u));
      i.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
      skipResume = true;
      startActivityForResult(i, REQ_CAM);
    } catch (Throwable e) {
      skipResume = false;
      js("onVoiceErr(" + JSONObject.quote("कैमरा नहीं खुला: " + e.getMessage()) + ")");
    }
  }
  void camResult(int rs) {
    if (rs == RESULT_OK && capFile != null && capFile.length() > 0) {
      capGot.add(Uri.fromFile(capFile));
      capLeft--;
      if (capLeft > 0) {
        android.widget.Toast.makeText(this, "अब पीछे का फोटो लीजिए (नहीं चाहिए तो कैमरे में वापस दबाइए)", android.widget.Toast.LENGTH_LONG).show();
        launchCamera();
        return;
      }
    } else if (capFile != null) {
      capFile.delete();
    }
    if (capGot.isEmpty()) { pendingField = ""; return; }
    final String fieldMode = pendingField;
    pendingField = "";
    final java.util.List<Uri> fresh = new ArrayList<>(capGot);
    capGot.clear();
    held.addAll(fresh);
    sendThumbs(fresh);
    ocrPhotos(new ArrayList<>(fresh), fieldMode);
  }

  // decodes a camera photo at reading size (long edge about 2400-4800 px) and turns it upright using its EXIF tag
  android.graphics.Bitmap loadBmp(Uri u, int minEdge) {
    try {
      String path = u.getPath();
      android.graphics.BitmapFactory.Options o = new android.graphics.BitmapFactory.Options();
      o.inJustDecodeBounds = true;
      android.graphics.BitmapFactory.decodeFile(path, o);
      int sample = 1, big = Math.max(o.outWidth, o.outHeight);
      while (big / (sample * 2) >= minEdge) sample *= 2;
      o = new android.graphics.BitmapFactory.Options();
      o.inSampleSize = sample;
      android.graphics.Bitmap b = android.graphics.BitmapFactory.decodeFile(path, o);
      if (b == null) return null;
      int ori = new android.media.ExifInterface(path).getAttributeInt(android.media.ExifInterface.TAG_ORIENTATION, 1);
      int deg = ori == 6 ? 90 : ori == 3 ? 180 : ori == 8 ? 270 : 0;
      if (deg != 0) {
        android.graphics.Matrix m = new android.graphics.Matrix();
        m.postRotate(deg);
        android.graphics.Bitmap r = android.graphics.Bitmap.createBitmap(b, 0, 0, b.getWidth(), b.getHeight(), m, true);
        if (r != b) b.recycle();
        b = r;
      }
      return b;
    } catch (Throwable e) { return null; }
  }

  // Photos stay attached to the open product form (so they can be re-read); they are deleted when the form is saved / cancelled.
  final java.util.List<Uri> held = new ArrayList<>();
  void readPack(Intent d) { }

  // small previews of the attached photos for the form
  void sendThumbs(final java.util.List<Uri> l) {
    new Thread(() -> {
      try {
        JSONArray arr = new JSONArray();
        for (Uri u : l) {
          try {
            android.graphics.Bitmap b0 = loadBmp(u, 700);
            if (b0 == null) continue;
            int mx = Math.max(b0.getWidth(), b0.getHeight());
            android.graphics.Bitmap b = android.graphics.Bitmap.createScaledBitmap(b0, Math.max(1, b0.getWidth() * 240 / mx), Math.max(1, b0.getHeight() * 240 / mx), true);
            java.io.ByteArrayOutputStream bo = new java.io.ByteArrayOutputStream();
            b.compress(android.graphics.Bitmap.CompressFormat.JPEG, 60, bo);
            arr.put("data:image/jpeg;base64," + android.util.Base64.encodeToString(bo.toByteArray(), android.util.Base64.NO_WRAP));
          } catch (Throwable e) {}
        }
        final String thumbs = arr.toString();
        runOnUiThread(() -> js("onPackPhotos(" + thumbs + ")"));
      } catch (Throwable e) {}
    }).start();
  }

  void clearHeld() {
    final java.util.List<Uri> l = new ArrayList<>(held);
    held.clear();
    deletePhotos(l);
  }

  void rereadHeld(String mode) {
    if (held.isEmpty()) { js("onVoiceErr(" + JSONObject.quote("कोई फोटो जुड़ी नहीं है") + ")"); return; }
    ocrPhotos(new ArrayList<>(held), mode == null ? "" : mode);
  }

  void ocrPhotos(final java.util.List<Uri> uris, final String fieldMode) {
    try {
      js("packBusy()");
      final java.util.List<android.graphics.Bitmap> bms = new ArrayList<>();
      for (Uri pu0 : uris) { android.graphics.Bitmap b0 = loadBmp(pu0, 2400); if (b0 != null) bms.add(b0); }
      final int n = bms.size();
      if (n == 0) { js("onVoiceErr(" + JSONObject.quote("फोटो खुली नहीं") + ")"); return; }
      final StringBuilder all = new StringBuilder();
      final String[] code = {""};
      final int[] done = {0};
      final JSONArray lines = new JSONArray();
      // product barcodes only (EAN/UPC/Code128...); QR codes on packs are usually batch/trace links, not the product code
      BarcodeScannerOptions bo = new BarcodeScannerOptions.Builder().setBarcodeFormats(
        Barcode.FORMAT_EAN_13, Barcode.FORMAT_EAN_8, Barcode.FORMAT_UPC_A, Barcode.FORMAT_UPC_E,
        Barcode.FORMAT_CODE_128, Barcode.FORMAT_CODE_39, Barcode.FORMAT_ITF).build();
      int pi = 0;
      for (android.graphics.Bitmap bm : bms) {
        final int pgIdx = pi++;
        final InputImage img = InputImage.fromBitmap(bm, 0);
        TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS).process(img).addOnCompleteListener(tt -> {
          if (tt.isSuccessful() && tt.getResult() != null) {
            all.append(tt.getResult().getText()).append("\n");
            // every text line with its relative height: big print on the front = product name
            try {
              float ph = Math.max(1f, img.getHeight());
              for (com.google.mlkit.vision.text.Text.TextBlock blk : tt.getResult().getTextBlocks()) {
                for (com.google.mlkit.vision.text.Text.Line ln : blk.getLines()) {
                  android.graphics.Rect bb = ln.getBoundingBox();
                  if (bb == null) continue;
                  JSONObject jo = new JSONObject();
                  jo.put("t", ln.getText());
                  jo.put("h", Math.min(bb.width(), bb.height()) / ph);
                  jo.put("pg", pgIdx);
                  lines.put(jo);
                }
              }
            } catch (Throwable ignore) {}
          }
          BarcodeScanning.getClient(bo).process(img).addOnCompleteListener(bt -> {
            if (bt.isSuccessful() && bt.getResult() != null && code[0].isEmpty()) {
              for (Barcode b : bt.getResult()) { String v = b.getRawValue(); if (v != null && !v.isEmpty()) { code[0] = v; break; } }
            }
            if (++done[0] == n) {
              if (all.length() == 0 && code[0].isEmpty()) js("onVoiceErr(" + JSONObject.quote("फोटो से कुछ पढ़ा नहीं गया (पहली बार इंटरनेट चाहिए)") + ")");
              else if (!fieldMode.isEmpty()) js("onPackField(" + JSONObject.quote(fieldMode) + "," + JSONObject.quote(all.toString()) + "," + lines.toString() + ")");
              else js("onPackText(" + JSONObject.quote(all.toString()) + "," + JSONObject.quote(code[0]) + "," + lines.toString() + ")");
            }
          });
        });
      }
    } catch (Throwable e) {
      js("onVoiceErr(" + JSONObject.quote("फोटो नहीं खुली: " + e.getMessage()) + ")");
    }
  }

  // Photos taken by the pack reader are deleted as soon as their text/barcode is read; nothing but text goes in the database.
  void deletePhotos(java.util.List<Uri> l) {
    try {
      for (Uri u : l) {
        try {
          if ("file".equals(u.getScheme()) && u.getPath() != null) new File(u.getPath()).delete();
          else getContentResolver().delete(u, null, null);
        } catch (Throwable e) {}
      }
    } catch (Throwable e) {}
    sweepScans();
  }
  // also clears any scanner leftovers (e.g. if the app was closed mid-scan)
  void sweepScans() {
    new Thread(() -> {
      try {
        File[] roots = { getFilesDir(), getCacheDir(), getExternalFilesDir(null), getExternalCacheDir() };
        for (File root : roots) {
          if (root == null) continue;
          File[] k = root.listFiles();
          if (k == null) continue;
          for (File x : k) if (x.getName().toLowerCase().contains("docscan")) deleteAll(x);
        }
      } catch (Throwable e) {}
    }).start();
  }

  // ---------- lifecycle ----------
  @Override public void onBackPressed() {
    if (panelOpen) js("closePanel()"); else super.onBackPressed();
  }
  @Override public void onRequestPermissionsResult(int c, String[] p, int[] r) {
    if (r.length > 0 && r[0] == PackageManager.PERMISSION_GRANTED) { hd.postDelayed(() -> js("autoStart()"), 800); schedule(1500); }
  }
  @Override protected void onPause() {
    super.onPause();
    if (skipResume) return;
    resumeAfter = keep;
    hd.removeCallbacks(applyTask);
    stopMic();
    try { if (speaking) tts.stop(); } catch (Exception e) {}
    speaking = false;
  }
  @Override protected void onResume() {
    super.onResume();
    if (skipResume) { skipResume = false; return; }
    if (resumeAfter && keep) schedule(1000);
  }
  @Override protected void onDestroy() {
    if (inst == this) inst = null;
    hd.removeCallbacks(applyTask);
    stopMic();
    try { if (model != null) model.close(); } catch (Throwable e) {}
    try { if (modelEn != null) modelEn.close(); } catch (Throwable e) {}
    try { if (tts != null) { tts.stop(); tts.shutdown(); } } catch (Exception e) {}
    super.onDestroy();
  }

  public class Bridge {
    @JavascriptInterface public void speak(String t, boolean listen) {
      runOnUiThread(() -> {
        wantListen = listen;
        hd.removeCallbacks(applyTask);
        stopMic();
        if (!ttsReady) { pending = t; return; }
        doSpeak(t);
      });
    }
    @JavascriptInterface public void listen() {
      runOnUiThread(() -> {
        if (!modelReady && modelFailed) { dialogListen(); return; }
        wantListen = true; asleep = false; touch();
        try { if (speaking) tts.stop(); } catch (Exception e) {}
        speaking = false;
        stopMic();
        schedule(150);
      });
    }
    @JavascriptInterface public boolean waReady() {
      try {
        String en = Settings.Secure.getString(getContentResolver(), Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
        String pk = getPackageName();
        return en != null && (en.contains(pk + "/" + WaService.class.getName()) || en.contains(pk + "/.WaService"));
      } catch (Exception e) { return false; }
    }
    @JavascriptInterface public void waOpenSettings() {
      runOnUiThread(() -> { try { startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)); } catch (Exception e) {} });
    }
    @JavascriptInterface public void waSend(String url) {
      runOnUiThread(() -> {
        WaService.pending = true;
        WaService.pendingAt = System.currentTimeMillis();
        boolean ok = false;
        for (String pkg : new String[]{"com.whatsapp", "com.whatsapp.w4b"}) {
          try {
            Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
            i.setPackage(pkg);
            startActivity(i);
            ok = true;
            break;
          } catch (Exception e) {}
        }
        if (!ok) { WaService.pending = false; js("onWaFail()"); return; }
        hd.removeCallbacks(waTimeout);
        hd.postDelayed(waTimeout, 30000);
      });
    }
    @JavascriptInterface public void scanPack() { runOnUiThread(() -> MainActivity.this.scanPack()); }
    @JavascriptInterface public void clearPhotos() { runOnUiThread(() -> MainActivity.this.clearHeld()); }
    @JavascriptInterface public void rereadPhotos(String m) { runOnUiThread(() -> MainActivity.this.rereadHeld(m)); }
    @JavascriptInterface public void scanField(String f) { runOnUiThread(() -> MainActivity.this.scanPack(1, f)); }
    @JavascriptInterface public void scanBarcode(String mode) { runOnUiThread(() -> scan(mode)); }
    @JavascriptInterface public void setGrammar(String g) { grammar = (g == null || g.length() < 3) ? null : g; }
    @JavascriptInterface public void panel(boolean open) { panelOpen = open; }
    @JavascriptInterface public boolean enAvailable() { return enReady; }
    @JavascriptInterface public void setLang(String l) { runOnUiThread(() -> { enMode = "en".equals(l) && enReady; stopMic(); schedule(200); }); }
    @JavascriptInterface public void sleep() { runOnUiThread(() -> { asleep = true; enMode = false; wantListen = false; pending = null;
      hd.removeCallbacks(idleTask); hd.removeCallbacks(applyTask); stopMic();
      try { if (speaking) tts.stop(); } catch (Exception e) {}
      speaking = false; js("onLang('hi')"); }); }
    @JavascriptInterface public void dialogListen() { runOnUiThread(() -> MainActivity.this.dialogListen("hi-IN")); }
    @JavascriptInterface public void dialogListenEn() { runOnUiThread(() -> MainActivity.this.dialogListen("en-IN")); }
    @JavascriptInterface public void keepOpen(boolean k) {
      runOnUiThread(() -> { keep = k; if (!k) wantListen = false; else touch(); schedule(100); });
    }
  }
}
