package com.dukan.sahayak;
import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.telephony.SmsManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import java.util.ArrayList;
import java.util.Locale;
import org.json.JSONObject;

public class MainActivity extends Activity {
  WebView w; TextToSpeech tts; SpeechRecognizer sr; boolean la = false;

  @Override protected void onCreate(Bundle b) {
    super.onCreate(b);
    requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO, Manifest.permission.SEND_SMS}, 1);
    w = new WebView(this); setContentView(w);
    WebSettings s = w.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true);
    w.setWebViewClient(new WebViewClient());
    tts = new TextToSpeech(this, st -> tts.setLanguage(new Locale("hi", "IN")));
    tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
      public void onStart(String id) {}
      public void onError(String id) {}
      public void onDone(String id) { if (la) runOnUiThread(() -> startListen()); }
    });
    w.addJavascriptInterface(new Bridge(), "Android");
    w.loadUrl("file:///android_asset/index.html");
  }

  void js(String code) { runOnUiThread(() -> w.evaluateJavascript(code, null)); }

  void startListen() {
    if (sr != null) sr.destroy();
    sr = SpeechRecognizer.createSpeechRecognizer(this);
    sr.setRecognitionListener(new RecognitionListener() {
      public void onResults(Bundle r) {
        ArrayList<String> l = r.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
        if (l != null && !l.isEmpty()) js("onVoice(" + JSONObject.quote(l.get(0)) + ")");
      }
      public void onError(int e) { js("onVoiceErr('सुनाई नहीं दिया, 🎤 दबाकर फिर बोलिए।')"); }
      public void onReadyForSpeech(Bundle p) {} public void onBeginningOfSpeech() {}
      public void onRmsChanged(float v) {} public void onBufferReceived(byte[] b) {}
      public void onEndOfSpeech() {} public void onPartialResults(Bundle p) {} public void onEvent(int t, Bundle p) {}
    });
    Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
    i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
    i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN");
    sr.startListening(i);
  }

  public class Bridge {
    @JavascriptInterface public void speak(String t, boolean listen) { la = listen; tts.speak(t, TextToSpeech.QUEUE_FLUSH, null, "u"); }
    @JavascriptInterface public void listen() { runOnUiThread(() -> startListen()); }
    @JavascriptInterface public void sendSms(String ph, String body) {
      try {
        String n = ph.length() == 10 ? "+91" + ph : ph;
        SmsManager sm = Build.VERSION.SDK_INT >= 31 ? getSystemService(SmsManager.class) : SmsManager.getDefault();
        sm.sendMultipartTextMessage(n, null, sm.divideMessage(body), null, null);
      } catch (Exception e) { js("onVoiceErr('SMS नहीं गया — SMS की अनुमति दें।')"); }
    }
  }
}
