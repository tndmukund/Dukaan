package com.dukan.sahayak;
import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import java.util.ArrayList;
import java.util.Locale;
import org.json.JSONObject;

public class MainActivity extends Activity {
  WebView w; TextToSpeech tts; SpeechRecognizer sr; boolean la = false, keep = false, listening = false;
  android.os.Handler hd = new android.os.Handler(android.os.Looper.getMainLooper());

  @Override protected void onCreate(Bundle b) {
    super.onCreate(b);
    requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, 1);
    w = new WebView(this); setContentView(w);
    WebSettings s = w.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true);
    w.setWebViewClient(new WebViewClient() {
      @Override public boolean shouldOverrideUrlLoading(WebView v, android.webkit.WebResourceRequest r) {
        if (r.getUrl().toString().startsWith("file:")) return false;
        try { startActivity(new Intent(Intent.ACTION_VIEW, r.getUrl())); } catch (Exception e) {}
        return true;
      }
    });
    tts = new TextToSpeech(this, st -> tts.setLanguage(new Locale("hi", "IN")));
    tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
      public void onStart(String id) {}
      public void onError(String id) {}
      public void onDone(String id) { if ((la || keep) && !listening) runOnUiThread(() -> startListen()); }
    });
    w.addJavascriptInterface(new Bridge(), "Android");
    w.loadUrl("file:///android_asset/index.html");
  }

  void js(String code) { runOnUiThread(() -> w.evaluateJavascript(code, null)); }

  void startListen() {
    listening = true; if (sr != null) sr.destroy();
    sr = SpeechRecognizer.createSpeechRecognizer(this);
    sr.setRecognitionListener(new RecognitionListener() {
      public void onResults(Bundle r) {
        ArrayList<String> l = r.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
        listening = false;
        if (l != null && !l.isEmpty()) js("onVoice(" + JSONObject.quote(l.get(0)) + ")");
        hd.postDelayed(() -> { if (keep && !listening && !tts.isSpeaking()) startListen(); }, 3000);
      }
      public void onError(int e) {
        listening = false;
        if (keep && e != SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS && e != SpeechRecognizer.ERROR_NETWORK && e != SpeechRecognizer.ERROR_SERVER)
          hd.postDelayed(() -> { if (keep && !listening && !tts.isSpeaking()) startListen(); }, 500);
        else js("onVoiceErr('सुनाई नहीं दिया, 🎤 दबाकर फिर बोलिए।')");
      }
      public void onReadyForSpeech(Bundle p) {} public void onBeginningOfSpeech() {}
      public void onRmsChanged(float v) {} public void onBufferReceived(byte[] b) {}
      public void onEndOfSpeech() {} public void onPartialResults(Bundle p) {} public void onEvent(int t, Bundle p) {}
    });
    Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
    i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
    i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN");
    i.putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 1800);
    i.putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 1800);
    sr.startListening(i);
  }

  public class Bridge {
    @JavascriptInterface public void speak(String t, boolean listen) { la = listen; tts.speak(t, TextToSpeech.QUEUE_FLUSH, null, "u"); }
    @JavascriptInterface public void listen() { runOnUiThread(() -> startListen()); }
    @JavascriptInterface public void keepOpen(boolean k) { keep = k; if (!k) runOnUiThread(() -> { if (sr != null) sr.cancel(); listening = false; }); }
  }
}
