package com.dukan.sahayak;
import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import java.util.ArrayList;
import java.util.Locale;
import org.json.JSONObject;

public class MainActivity extends Activity {
  WebView w; TextToSpeech tts; SpeechRecognizer sr; boolean la = false, keep = false, listening = false, ttsReady = false;
  String pending = null;
  long last = 0;
  android.os.Handler hd = new android.os.Handler(android.os.Looper.getMainLooper());

  @Override protected void onCreate(Bundle b) {
    super.onCreate(b);
    getWindow().addFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
    requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, 1);
    w = new WebView(this); setContentView(w);
    WebSettings s = w.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true);
    w.setWebViewClient(new WebViewClient() {
      @Override public void onPageFinished(WebView v, String u) {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == android.content.pm.PackageManager.PERMISSION_GRANTED) hd.postDelayed(() -> js("autoStart()"), 1500);
      }
      @Override public boolean shouldOverrideUrlLoading(WebView v, android.webkit.WebResourceRequest r) {
        if (r.getUrl().toString().startsWith("file:")) return false;
        try { startActivity(new Intent(Intent.ACTION_VIEW, r.getUrl())); } catch (Exception e) {}
        return true;
      }
    });
    tts = new TextToSpeech(this, st -> {
      if (st != TextToSpeech.SUCCESS) { err("फ़ोन में Text-to-speech इंजन नहीं मिला। Settings > Text-to-speech में Google इंजन चुनें।"); return; }
      int r = tts.setLanguage(new Locale("hi", "IN"));
      if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
        err("हिंदी आवाज़ फ़ोन में नहीं है। खुलने वाली स्क्रीन में Hindi डाउनलोड करें, फिर ऐप दोबारा खोलें।");
        try { startActivity(new Intent(TextToSpeech.Engine.ACTION_INSTALL_TTS_DATA)); } catch (Exception e) {}
      }
      ttsReady = true;
      if (pending != null) { String p = pending; pending = null; doSpeak(p); }
    });
    tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
      public void onStart(String id) {}
      public void onError(String id) { if ((la || keep) && !listening) hd.postDelayed(() -> { if (!listening) startListen(); }, 400); }
      public void onDone(String id) { if ((la || keep) && !listening) runOnUiThread(() -> startListen()); }
    });
    w.addJavascriptInterface(new Bridge(), "Android");
    w.loadUrl("file:///android_asset/index.html");
  }

  @Override public void onRequestPermissionsResult(int c, String[] p, int[] r) {
    if (r.length > 0 && r[0] == android.content.pm.PackageManager.PERMISSION_GRANTED) hd.postDelayed(() -> js("autoStart()"), 800);
  }

  void doSpeak(String t) {
    int r = tts.speak(t, TextToSpeech.QUEUE_FLUSH, null, "u");
    if (r != TextToSpeech.SUCCESS && (la || keep) && !listening) runOnUiThread(() -> startListen());
  }

  void err(String m) { hd.postDelayed(() -> js("onVoiceErr(" + JSONObject.quote(m) + ")"), 2500); }

  void js(String code) { runOnUiThread(() -> w.evaluateJavascript(code, null)); }

  void startListen() {
    long now = android.os.SystemClock.uptimeMillis();
    if (listening && now - last < 2500) return;
    last = now; listening = true; if (sr != null) sr.destroy();
    sr = SpeechRecognizer.createSpeechRecognizer(this);
    sr.setRecognitionListener(new RecognitionListener() {
      public void onResults(Bundle r) {
        ArrayList<String> l = r.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
        listening = false;
        if (l != null && !l.isEmpty()) js("onVoice(" + JSONObject.quote(l.get(0)) + ")");
        hd.postDelayed(() -> { if (keep && !listening && !tts.isSpeaking()) startListen(); }, 3000);
      }
      public void onError(int e) {
        listening = false;
        if (e == 12 || e == 13) { js("onVoiceErr('हिंदी पहचान इस फ़ोन में उपलब्ध नहीं (कोड " + e + "). Google ऐप > Settings > Voice > Languages में Hindi जोड़ें।')"); return; }
        if (e == SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS) { js("onVoiceErr('माइक की अनुमति दें: Settings > Apps > दुकान सहायक > Permissions')"); return; }
        boolean net = e == 1 || e == 2 || e == 4;
        js("onStatus('" + (net ? "इंटरनेट चालू करें" : "सुनाई नहीं दिया, फिर सुन रहा हूँ…") + " (कोड " + e + ")')");
        if (keep) hd.postDelayed(() -> { if (keep && !listening && !tts.isSpeaking()) startListen(); }, net ? 3000 : (e == 8 ? 1200 : 600));
      }
      public void onReadyForSpeech(Bundle p) { js("onStatus('🎤 बोलिए…')"); } public void onBeginningOfSpeech() {}
      public void onRmsChanged(float v) {} public void onBufferReceived(byte[] b) {}
      public void onEndOfSpeech() { js("onStatus('समझ रहा हूँ…')"); }
      public void onPartialResults(Bundle p) { ArrayList<String> l = p.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION); if (l != null && !l.isEmpty()) js("onPartial(" + JSONObject.quote(l.get(0)) + ")"); }
      public void onEvent(int t, Bundle p) {}
    });
    Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
    i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
    i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN");
    i.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true);
    i.putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, getPackageName());
    i.putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 1800);
    i.putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 1800);
    sr.startListening(i);
  }

  public class Bridge {
    @JavascriptInterface public void speak(String t, boolean listen) { la = listen; if (!ttsReady) { pending = t; return; } doSpeak(t); }
    @JavascriptInterface public void listen() { runOnUiThread(() -> startListen()); }
    @JavascriptInterface public void keepOpen(boolean k) { keep = k; if (!k) runOnUiThread(() -> { if (sr != null) sr.cancel(); listening = false; }); }
  }
}
